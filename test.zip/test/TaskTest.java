package com.thread.pool.test;

public class TaskTest implements Runnable {

    // 保存任务所需要的数据
    private Object threadPoolTaskData;
    private static int consumerTaskSleepTime = 2000;

    TaskTest(Object task) {
        this.threadPoolTaskData = task;
    }

    public void run() {
        System.out.println("start .. " + threadPoolTaskData);

        try {
            Thread.sleep(consumerTaskSleepTime);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            System.out.println("finished " + threadPoolTaskData);
            threadPoolTaskData = null;
        }


    }
}
