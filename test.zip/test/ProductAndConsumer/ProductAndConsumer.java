package com.thread.pool.test.ProductAndConsumer;

import org.apache.tomcat.jni.Time;

import java.util.Random;
import java.util.concurrent.*;

public class ProductAndConsumer {
    public static void main(String[] args) {
        test3();
    }

    private static void test1() {
        ArrayBlockingQueue<Integer> queue = new ArrayBlockingQueue<Integer>(20);

        //为多生产者和多消费者分别开创的线程池
        ThreadPoolExecutor productPool =
                new ThreadPoolExecutor(10, 20, 60,
                        TimeUnit.MILLISECONDS, new ArrayBlockingQueue(5),
                        new ThreadPoolExecutor.CallerRunsPolicy());
        ThreadPoolExecutor consumerPool =
                new ThreadPoolExecutor(10, 20, 60,
                        TimeUnit.MILLISECONDS, new ArrayBlockingQueue(5),
                        new ThreadPoolExecutor.CallerRunsPolicy());

        System.out.println("ProductAndConsumer  start");
        for (int i = 0; i < 100; i++) {

            productPool.execute(new ProductThread(i, queue));
            consumerPool.execute(new ConsumerThread(queue));
        }
        productPool.shutdown();
        consumerPool.shutdown();
    }


    private static void test2() {
        ConcurrentLinkedQueue<Object> cQueue = new ConcurrentLinkedQueue<Object>();
        ConcurrentLinkedQueue<Object> running = new ConcurrentLinkedQueue<Object>();

//        cQueue.peek();


        for (int i = 0; i < 100; i++) {
            cQueue.add(i);
        }


        if (!cQueue.isEmpty()) {
            Object obj = cQueue.peek();
        }
    }


    private static void test3() {
        final int THREAD_COUNT = 30;//总共的线程数
        ExecutorService threadPool = Executors.newFixedThreadPool(THREAD_COUNT);
        final Semaphore semaphore = new Semaphore(10);//可以并发执行的线程数
        for (int i = 0; i < THREAD_COUNT; i++) {
            final int j = i;
            threadPool.execute(new Runnable() {
                public void run() {
                    try {
                        semaphore.acquire();//acquire()获取一个许可证
                        /**
                         * 要执行的代码块
                         */
                        Random r = new Random(13);
                        int slNum = r.nextInt(12) * 1000;
                        if (j == 9){
                            slNum = 30 * 1000;
                        }
                        Thread.sleep(slNum);
                        System.out.println(System.currentTimeMillis() + "     " + j + "    zl");

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } finally {
                        semaphore.release();//使用完之后调用release()归还许可证
                    }
                }

            });
        }
        threadPool.shutdown();
    }
}